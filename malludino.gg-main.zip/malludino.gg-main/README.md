hello,
this was made for fun.
this is a teplate for custom chrome dino game. All images used here should obey the policies of github. 
